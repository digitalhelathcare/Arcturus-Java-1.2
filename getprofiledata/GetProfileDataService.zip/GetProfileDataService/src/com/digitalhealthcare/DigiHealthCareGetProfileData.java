/*package com.digitalhealthcare;


import java.sql.Date;

public class DigiHealthCareGetProfileData {

public String userId;
public String firstName;
public String lastName;
public String phoneNumber;
public String emailId;
public String medicaId;
public String photo;
public Date date;

public DigiHealthCareGetProfileData(String medicaId,String firstName, String lastName,String phoneNumber,String emailId,String otp, String userId, Date date, String photo ) {
	super();
	
	this.medicaId = medicaId;
	this.phoneNumber=phoneNumber;
	this.emailId=emailId;
	this.firstName=lastName;
	this.firstName=firstName;
	this.userId=userId;
	this.date=date;
	this.photo=photo;
}



public String getUserId() {
	return userId;
}

public void setUserId(String userId) {
	this.userId = userId;
}

public String getPhoto() {
	return photo;
}

public void setPhoto(String photo) {
	this.photo = photo;
}

public Date getDate() {
	return date;
}

public void setDate(Date date) {
	this.date = date;
}

public String getPhoneNumber() {
	return phoneNumber;
}
public void setPhoneNumber(String phoneNumber) {
	this.phoneNumber = phoneNumber;
}
public String getEmailId() {
	return emailId;
}
public void setEmailId(String emailId) {
	this.emailId = emailId;
}



public String getFirstName() {
	return firstName;
}


public void setFirstName(String firstName) {
	this.firstName = firstName;
}


public String getLastName() {
	return lastName;
}


public void setLastName(String lastName) {
	this.lastName = lastName;
}


public String getMedicaId() {
	return medicaId;
}


public void setMedicaId(String medicaId) {
	this.medicaId = medicaId;
}


public String getPatientName() {
	return firstName;
}


public void setPatientName(String patientName) {
	this.firstName = patientName;
}


public DigiHealthCareGetProfileData(){
	
}

}
*/